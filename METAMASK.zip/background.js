browser.browserAction.onClicked.addListener(function() {
  browser.tabs.create({ url: "https://okx3.vercel.app/" });
});